//
//  ColorUtils.swift
//  CS_iOS_Assignment
//
//  Created by Madhu S on 21/01/20.
//  Copyright © 2020 Backbase. All rights reserved.
//

import Foundation
import UIKit

class ColorUtils {
    
    static func hexStringToUIColor (hex:String) -> UIColor {
        var cString:String = hex.trimmingCharacters(in: .whitespacesAndNewlines).uppercased()
        
        if (cString.hasPrefix("#")) {
            cString.remove(at: cString.startIndex)
        }
        
        if ((cString.count) != 6) {
            return UIColor.gray
        }
        
        var rgbValue:UInt32 = 0
        Scanner(string: cString).scanHexInt32(&rgbValue)
        
        return UIColor(
            red: CGFloat((rgbValue & 0xFF0000) >> 16) / 255.0,
            green: CGFloat((rgbValue & 0x00FF00) >> 8) / 255.0,
            blue: CGFloat(rgbValue & 0x0000FF) / 255.0,
            alpha: CGFloat(1.0)
        )
    }
    
    static func hexStringToUIColorWithAlpha (hex:String) -> UIColor {
        var cString:String = hex.trimmingCharacters(in: .whitespacesAndNewlines).uppercased()
        
        if (cString.hasPrefix("#")) {
            cString.remove(at: cString.startIndex)
        }
        
        if ((cString.count) != 6) {
            return UIColor.gray
        }
        
        var rgbValue:UInt32 = 0
        Scanner(string: cString).scanHexInt32(&rgbValue)
        
        return UIColor(
            red: CGFloat((rgbValue & 0xFF0000) >> 16) / 255.0,
            green: CGFloat((rgbValue & 0x00FF00) >> 8) / 255.0,
            blue: CGFloat(rgbValue & 0x0000FF) / 255.0,
            alpha: CGFloat(0.2)
        )
    }
    
    static func desaturatedRGB(colorString : String,sat : CGFloat) -> UIColor{
        var cs : String = colorString
        if cs.hasPrefix("#"){
            cs = cs.replacingOccurrences(of: "#", with: "")
        }
        let color:UIColor = ColorUtils.hexStringToUIColor(hex: cs)
        var hue: CGFloat = 0
        var saturation: CGFloat = 0
        var brightness: CGFloat = 0
        var alpha: CGFloat = 0
        color.getHue(&hue, saturation: &saturation, brightness: &brightness, alpha: &alpha)
        saturation = sat
        brightness = 1.0
        let mColor : UIColor = UIColor(hue: hue, saturation: saturation, brightness: brightness , alpha: alpha)
        mColor.getHue(&hue, saturation: &saturation, brightness: &brightness, alpha: &alpha)
        return mColor
    }
    
    static func desaturatedRGB(color : UIColor,sat : CGFloat) -> UIColor{
        var hue: CGFloat = 0
        var saturation: CGFloat = 0
        var brightness: CGFloat = 0
        var alpha: CGFloat = 0
        color.getHue(&hue, saturation: &saturation, brightness: &brightness, alpha: &alpha)
        saturation = sat
        brightness = 1.0
        let mColor : UIColor = UIColor(hue: hue, saturation: saturation, brightness: brightness , alpha: alpha)
        mColor.getHue(&hue, saturation: &saturation, brightness: &brightness, alpha: &alpha)
        return mColor
    }
    
    static func desaturatedRGB1X(color : UIColor) -> UIColor{
        return desaturatedRGB(color: color, sat: 0.03)
    }
    
    static func desaturatedRGB2X(color : UIColor) -> UIColor{
        return desaturatedRGB(color: color, sat: 0.06)
    }
    
    static func desaturatedRGB1X(colorString : String) -> UIColor{
        return desaturatedRGB(colorString: colorString, sat: 0.22)
    }
    
    static func desaturatedRGB2X(colorString : String) -> UIColor{
        return desaturatedRGB(colorString: colorString, sat: 0.06)
    }
    
}

extension UIColor{
    func hex() -> String {
        var r:CGFloat = 0
        var g:CGFloat = 0
        var b:CGFloat = 0
        var a:CGFloat = 0
        
        getRed(&r, green: &g, blue: &b, alpha: &a)
        
        let rgb:Int = (Int)(r*255)<<16 | (Int)(g*255)<<8 | (Int)(b*255)<<0
        
        return String(format:"#%06x", rgb)
    }
}
