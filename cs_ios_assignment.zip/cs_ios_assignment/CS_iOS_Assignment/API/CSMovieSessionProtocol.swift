//
//  CSMovieSessionProtocol.swift
//  CS_iOS_Assignment
//
//  Created by Madhu S on 20/01/20.
//  Copyright © 2020 Backbase. All rights reserved.
//

import Foundation

protocol URLSessionDataTaskProtocol {
    func cancel()
    func resume()
    func suspend()
    var state: URLSessionTask.State { get }
}

extension URLSessionDataTask: URLSessionDataTaskProtocol { }

protocol CSMovieSessionProtocol {
    func dataTask(with request: URLRequest, completion: @escaping (Data?, URLResponse?, Error?) -> Void) -> URLSessionDataTaskProtocol
}
extension URLSession: CSMovieSessionProtocol {
    func dataTask(with request: URLRequest, completion: @escaping (Data?, URLResponse?, Error?) -> Void) -> URLSessionDataTaskProtocol {
        return dataTask(with: request, completionHandler: completion)
    }
}
