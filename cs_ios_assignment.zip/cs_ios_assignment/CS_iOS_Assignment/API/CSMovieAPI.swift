//
//  CSMovieAPI.swift
//  CS_iOS_Assignment
//
//  Created by Madhu S on 20/01/20.
//  Copyright © 2020 Backbase. All rights reserved.
//

import Foundation
final class CSMovieAPI {
    
    enum APIError: Error {
        case parsingError(String)
        case networkError(Error)
        case badQuery(String)
        case curruptedData(Error)
        case emptyResult
    }
    
//    let apiKEY = "55957fcf3ba81b137f8fc01ac5a31fb5"
    let status = KeyChain.save(key: "myApIKey", data: Data(from: "55957fcf3ba81b137f8fc01ac5a31fb5"))


    static let imageBaseURL = URL(string: "http://image.tmdb.org/t/p/")!
    private let baseURL = "https://api.themoviedb.org/3/"
    private let apiKEY = String((KeyChain.load(key: "myApIKey")?.to(type: String.self))!)

    private let session: CSMovieSessionProtocol
    
    init(session: CSMovieSessionProtocol) {
        self.session = session
    }
}

extension CSMovieAPI {

    
    func discover(
        page: Int,
        success: @escaping (CSMoviesResponse) -> Void,
        failure: @escaping (APIError) -> Void)
    {
        
        // hardcoded for simplicity, in real project it would be request builder
        let endpoint = baseURL + "discover/movie?sort_by=popularity.desc&api_key=\(apiKEY)&page=\(page)"
        let url = URL(string: endpoint)!
        let discoverRequest = URLRequest(url: url)
        request(discoverRequest, success: success, failure: failure)
    }
    func playing(
        page: Int,
        success: @escaping (CSMoviesResponse) -> Void,
        failure: @escaping (APIError) -> Void)
    {
        
        // hardcoded for simplicity, in real project it would be request builder
        let endpoint = baseURL + "movie/now_playing?language=en-US&page=undefined&api_key=\(apiKEY)"
        let url = URL(string: endpoint)!
        let discoverRequest = URLRequest(url: url)
        request(discoverRequest, success: success, failure: failure)
    }
    func getDetailedMovie(
        movieId: Int,
        success: @escaping (CSMoviesDetailsResponse) -> Void,
        failure: @escaping (APIError) -> Void)
    {
        // hardcoded for simplicity, in real project it would be request builder
        let endpoint = baseURL + "movie/\(movieId)?api_key=\(apiKEY)"
        let url = URL(string: endpoint)!
        let discoverRequest = URLRequest(url: url)
        requestForDetail(discoverRequest, success: success, failure: failure)
    }
}
extension CSMovieAPI {
    
    private func request(
        _ request: URLRequest,
        success: @escaping (CSMoviesResponse) -> Void,
        failure: @escaping (APIError) -> Void)
    {
        let task = session.dataTask(with: request) { (data, response, error) in
            if let error = error {
                failure(.networkError(error))
                return
            }
            
            guard let data = data else {
                failure(.emptyResult)
                return
            }
            
            do {
                let value = try JSONDecoder().decode(
                    CSMoviesResponse.self,
                    from: data
                )
                success(value)
            } catch {
                print(error)
                failure(.curruptedData(error))
            }
        }
        task.resume()
    }
    private func requestForDetail(
            _ request: URLRequest,
            success: @escaping (CSMoviesDetailsResponse) -> Void,
            failure: @escaping (APIError) -> Void)
        {
            let task = session.dataTask(with: request) { (data, response, error) in
                if let error = error {
                    failure(.networkError(error))
                    return
                }
                guard let data = data else {
                    failure(.emptyResult)
                    return
                }
                do {
                    let value = try JSONDecoder().decode(
                        CSMoviesDetailsResponse.self,
                        from: data
                    )
                    success(value)
                } catch {
                    print(error)
                    failure(.curruptedData(error))
                }
            }
            task.resume()
        }
}
extension CSMovieAPI {
    static func toMovie(_ data: CSMovieAPI.MovieResponse) -> Movies {
        
        let poster: URL? = {
            guard let posterPath = data.posterPath else {return nil}
            return imageBaseURL
                .appendingPathComponent("w780")
                .appendingPathComponent(posterPath)
        }()
        
        return Movies(
            id: data.id,
            poster: poster,
            name: data.title,
            released: data.releaseDate.date,
            overview: data.overview ?? "", popularity: data.popularity, votecount: data.votecount, video:data.video, adult: data.adult, originallanguage: "en", backdrop: data.backdrop, voteaverage: data.voteaverage
        )
    }
    
    static func toMovieDetails(_ data: CSMovieAPI.GenresResponse) -> Genres {
        return Genres(
            id: data.id,
            name: data.title
        )
    }
}
