//
//  Root.swift
//  CS_iOS_Assignment
//
//  Created by Madhu S on 20/01/20.
//  Copyright © 2020 Backbase. All rights reserved.
//
import UIKit
import Foundation

final class Root {
    
    private let api = CSMovieAPI(session: URLSession.shared)
    private let suggestionsService = CSMovieService(
        capacity: 10,
        storage: MoviesStorage(name: "suggestions.json")
    )

    weak var window: UIWindow!
    
    init(window: UIWindow) {
        self.window = window
    }
    
    
    // MARK: Presentation
    
    func presentMainScreen() {
        guard let window = window else { return }
        window.rootViewController = makeTabBarViewController()
        window.makeKeyAndVisible()
    }
    
    
    // MARK: View Controllers Assemblies

    private func makeTabBarViewController() -> UIViewController {
        return makePopularScreen()
    }
    
    
    
    
    private func makePopularScreen() -> UIViewController {
        
        // reusing of the MoviesListViewController
        let popularViewController: CSMoviesListViewController = {
            let vc = CSMoviesListViewController.instantiate()
            vc.title = "MOVIEBOX"
            UINavigationBar.appearance().barTintColor = ColorUtils.hexStringToUIColor(hex: "212121")
//            UINavigationBar.appearance().tintColor =

            UINavigationBar.appearance().titleTextAttributes = [NSAttributedString.Key.foregroundColor : ColorUtils.hexStringToUIColor(hex: "FCD052")]

            
            return vc
        }()
        
       
        let detailsScreen = CSMovieDetailsViewController.instantiate()
        let popularMoviesModel = CSPopularMoviesModel(api: api)

        let popularMoviesViewModel =  CSMoviesViewModel(model: popularMoviesModel)
        popularViewController.viewModel = popularMoviesViewModel
        
        let navigation = popularViewController.wrappedInNavigationController()

        popularMoviesViewModel.onSelectMovie = { [weak navigation] movie in
            detailsScreen.movie = movie
            DispatchQueue.main.async {
                navigation?.pushViewController(detailsScreen, animated: true)
            }
        }
        return navigation
    }
    
    
}

private extension UIViewController {
    func wrappedInNavigationController() -> UINavigationController {
        let nc = UINavigationController(rootViewController: self)
        nc.title = self.title
        nc.tabBarItem = self.tabBarItem
        return nc
    }
    
}
