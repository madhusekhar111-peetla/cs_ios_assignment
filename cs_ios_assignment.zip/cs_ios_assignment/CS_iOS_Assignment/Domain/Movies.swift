//
//  Movies.swift
//  CS_iOS_Assignment
//
//  Created by Madhu S on 20/01/20.
//  Copyright © 2020 Backbase. All rights reserved.
//

import Foundation
struct Movies {
    let id: Int
    let poster: URL?
    let name: String
    let released: Date
    let overview: String
    let popularity: Float
    let votecount: Int
    let video: Bool
    let adult: Bool
    let originallanguage: String
    let backdrop: URL?
    let voteaverage: Float

}
struct Genres {
    let id: Int
    let name: String
}
