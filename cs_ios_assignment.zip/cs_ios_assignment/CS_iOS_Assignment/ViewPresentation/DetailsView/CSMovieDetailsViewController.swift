//
//  CSMovieDetailsViewController.swift
//  CS_iOS_Assignment
//
//  Created by Madhu S on 20/01/20.
//  Copyright © 2020 Backbase. All rights reserved.
//

import UIKit
import Kingfisher
class CSMovieDetailsViewController: UIViewController {
    
//    var delegate: CSPopularMoviesModelDelegate?

    
    @IBOutlet var posterImageView: UIImageView!
    @IBOutlet var nameLabel: UILabel!
    @IBOutlet var overviewLabel: UILabel!
    @IBOutlet var releaseYearLabel: UILabel!
    @IBOutlet var genresLabel: UILabel!
    var genresText:String! = ""
    var genres:[Genres]  = [Genres]()
    
    var movie: Movies? {
        didSet {
            DispatchQueue.main.async {
                guard self.isViewLoaded, let movie = self.movie else { return }
                self.render(movie: movie)
            }
        }
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        if let movie = movie {
            render(movie: movie)
        }
    }
    
    private func render(movie: Movies) {
        nameLabel.text = movie.name
        overviewLabel.text = movie.overview
        let formatter = DateFormatter()
        formatter.dateFormat = "yyyy-MM-dd"
        releaseYearLabel.text = formatter.string(from: movie.released)

        //
        if let imageURL = movie.poster {
            posterImageView.kf.setImage(with: imageURL)
        }
    }
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        if let myLoadedString = UserDefaults.standard.string(forKey: "myString") {
            genresLabel.text = myLoadedString
        }


    }
    func setdat(_ str:String)  {
        
        genresLabel.text = str
    }
    func genresData(data: [Genres]) {
        for itme in data {
            genresText  = genresText + "    " + itme.name
        }
        UserDefaults.standard.set(genresText, forKey: "myString")
    }
    
}

extension CSMovieDetailsViewController {
    
    static func instantiate() -> CSMovieDetailsViewController {
        let vc = UIStoryboard(name: "CSMovieDetails", bundle: nil)
            .instantiateInitialViewController() as! CSMovieDetailsViewController
        return vc
    }
}
