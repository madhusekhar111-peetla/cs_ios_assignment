//
//  CSMoviesViewModel.swift
//  CS_iOS_Assignment
//
//  Created by Madhu S on 20/01/20.
//  Copyright © 2020 Backbase. All rights reserved.
//

import Foundation

class CSMoviesViewModel {
    
    // MARK: Interface
    
    enum State {
        case loading
        case empty
        case error(String)
        case movies
        case playing
        case playingmovies
    }
    
    // Output
    var state: Observable<State>
    
    // Input
    var onSelectMovie: ((Movies) -> Void)?
    
    // MARK: - Implementation
    private let model: CSPaginatedMoviesModel?
    private var cancelSubscription: CancelSubscription?
    private var movies: [Movies] {
        if case .movies(let movies)? = model?.state.value {
            return movies
        }
        return []
    }
    private var playingmovies: [Movies] {
        if case .playingmovies(let movies)? = model?.state.value {
            return movies
        }
        return []
    }
    init(model: CSPaginatedMoviesModel) {
        self.model = model
        self.state = Observable(State.movies)
        // binding
        self.cancelSubscription = model.state.subscribe(on: .main) { [weak self] state in
            guard let self = self else { return }
            switch state {
            case .loading:
                self.state.value = .loading
            case .movies(let movies):
                if movies.count > 0 { self.state.value = .movies}
                else {self.state.value = .empty }
            case .pageError(_): break
            case .fatalError(let message):
                self.state.value = .error(message)
            case .palying:
                self.state.value = .playingmovies
                break
            case .playingmovies(let movies):
                if movies.count > 0 { self.state.value = .playingmovies}
                else {self.state.value = .empty }
                break
            }
        }

    }
    
    deinit {
        cancelSubscription?()
    }
    
    func movie(at index: Int) -> Movies? {
        guard 0..<movies.count ~= index else { return nil }
        return movies[index]
    }
    
    var moviesCount: Int {
        return movies.count
    }
    
    func playingmovies(at index: Int) -> Movies? {
        guard 0..<playingmovies.count ~= index else { return nil }
        return playingmovies[index]
    }

    var playingmoviesCount: Int {
        return playingmovies.count
    }
    
    func selectMovie(at index: Int) {
        guard let movie = movie(at: index) else { return }
        onSelectMovie?(movie)
    }
    
    func loadNextPage() {
        guard let model = model else { return }
        model.load(page: model.lastPage + 1)
    }
    
    func loadPlaying() {
        guard let model = model else { return }
        model.playingload(page: model.lastPage + 1)
    }
    func getDeatils(movieId:Int, success: @escaping ([Genres]) -> Void) {
        guard let model = model else { return }
        model.movieDetails(movieId: movieId, success: { response in
            success(response)
            })
            
    }
}
