//
//  CSMoviesListViewController.swift
//  CS_iOS_Assignment
//
//  Created by Madhu S on 20/01/20.
//  Copyright © 2020 Backbase. All rights reserved.
//

import UIKit

class CSMoviesListViewController: UIViewController {

    @IBOutlet weak var emptyDatasetLabel: UILabel!
    @IBOutlet weak var tableView: UITableView!
    @IBOutlet weak var collectionView: UICollectionView!

    var viewModel: CSMoviesViewModel!
    private var cancelSubscription: CancelSubscription?

    override func viewDidLoad() {
        super.viewDidLoad()
        tableView.rowHeight = UITableView.automaticDimension
//        tableView.estimatedRowHeight = 250
        DispatchQueue.main.async {
            self.tableView.reloadData()
            self.collectionView.reloadData()

        }
        tableView.reloadData()
        collectionView.reloadData()

    }
    
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)

    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        
        cancelSubscription = viewModel.state.subscribe(on: .main) { [weak self] state in
            self?.handle(state)
        }
        viewModel.loadPlaying()
        viewModel.loadNextPage()
        
    }
    
    /// Changes the representation regarding the view model state
    func handle(_ state: CSMoviesViewModel.State) {
        switch state {
            
        case .loading, .empty:
            tableView.isHidden = true
            emptyDatasetLabel.isHidden = false

        case .error(let message):
            tableView.isHidden = false
            emptyDatasetLabel.isHidden = true

            let alert = UIAlertController(
                title: "ERROR",
                message: message,
                preferredStyle: .alert
            )
            present(alert, animated: true)
            
        case .movies:
            tableView.isHidden = false
            emptyDatasetLabel.isHidden = true
            DispatchQueue.main.async {
                self.tableView.reloadData()

            }
        case .playingmovies:
            collectionView.isHidden = false
            emptyDatasetLabel.isHidden = true
            DispatchQueue.main.async {

                self.collectionView.reloadData()
            }
        case .playing:
            viewModel.loadPlaying()

            
        }
    }
    
    deinit {
        cancelSubscription?()
    }
}

extension CSMoviesListViewController: UICollectionViewDataSource {
    
    
    func numberOfSections(in collectionView: UICollectionView) -> Int{
        return 1
    }
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
//        if viewModel.playingmoviesCount == 0 {
//            viewModel.loadPlaying()
//        }
        return viewModel.playingmoviesCount
    }
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize
    {
       return CGSize(width: 110, height: 149)
    }

    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: MovieCollectionViewCell.identifier, for: indexPath) as! MovieCollectionViewCell
        guard let movie = viewModel.playingmovies(at: indexPath.row) else {
            return cell
        }
        cell.configure(with: movie)
        return cell
    }
    
    
    
}
extension CSMoviesListViewController: UICollectionViewDelegate {
    func collectionView(_ collectionView: UICollectionView, willDisplay cell: UICollectionViewCell, forItemAt indexPath: IndexPath){
        
        if indexPath.row == viewModel.moviesCount - 5 {
            collectionView.scrollToItem(at: indexPath, at: .left, animated: true)
        }

    }
    
}

extension CSMoviesListViewController: UITableViewDataSource {
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 100;
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
//        if viewModel.moviesCount == 0 {
//            viewModel.loadNextPage()
//        }
        return viewModel.moviesCount
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: MovieCell.identifier) as! MovieCell
        guard let movie = viewModel.movie(at: indexPath.row) else {
            return cell
        }
        cell.configure(with: movie)
        return cell
    }
    
    
}

extension CSMoviesListViewController: UITableViewDelegate {
    
    func tableView(_ tableView: UITableView, willDisplay cell: UITableViewCell, forRowAt indexPath: IndexPath) {
        if indexPath.row == viewModel.moviesCount - 7 {
            viewModel.loadNextPage()
        }
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        tableView.deselectRow(at: indexPath, animated: true)
        guard let movie = viewModel.movie(at: indexPath.row) else {
            return 
        }
        
        DispatchQueue.global(qos: .background).async {
            self.viewModel.getDeatils(movieId: movie.id, success: { response in
                DispatchQueue.main.async {
                    let dvc = CSMovieDetailsViewController()
                    
                    dvc.genresData(data: response)
                }
            })
            self.viewModel.selectMovie(at: indexPath.row)
        }

            

    }
}


// MARK: - Instantiation
extension CSMoviesListViewController {
    
    /// Instntiates view controller and setups all the dependencies
    static func instantiate() -> CSMoviesListViewController {
        let vc = UIStoryboard(name: "CSMovies", bundle: nil)
            .instantiateInitialViewController() as! CSMoviesListViewController
        return vc
    }
}

