//
//  MovieCell.swift
//  CS_iOS_Assignment
//
//  Copyright © 2019 Backbase. All rights reserved.
//

import UIKit
import Kingfisher
//
// MARK: - Movie Cell
//
class MovieCell: UITableViewCell {
    
    
    // MARK: - IBOutlets
    //
    @IBOutlet weak var title: UILabel!
    @IBOutlet weak var rating: RatingView!
    @IBOutlet weak var releaseDate: UILabel!
    @IBOutlet weak var poster: UIImageView!
    @IBOutlet weak var ratingValue: UILabel!
    
    
    static let identifier: String = "MovieCell"
    
    static var nib: UINib {
        return UINib(nibName: identifier, bundle: Bundle(for: self))
    }
    
    override func awakeFromNib() {
        super.awakeFromNib()
        releaseDate.layer.borderColor = UIColor(white: 151.0 / 255.0, alpha: 1.0).cgColor
        releaseDate.layer.borderWidth = 0.5
        releaseDate.layer.cornerRadius = 2
    }
    
    override func prepareForReuse() {
        super.prepareForReuse()
        poster.image = nil
        title.text = nil
        //        overviewLabel.text = nil
        releaseDate.text = nil
    }
    
    func configure(with movie: Movies) {
        title.text = movie.name
        //        overviewLabel.text = movie.overview
        let formatter = DateFormatter()
        formatter.dateFormat = "yyyy-MM-dd"
        releaseDate.text = formatter.string(from: movie.released)
        
        if movie.voteaverage < 3 {
            rating.trackClr = ColorUtils.desaturatedRGB1X(colorString: "E6301A")
            rating.progressClr = ColorUtils.hexStringToUIColor(hex: "E6301A")
            
        }else if movie.voteaverage > 3 && movie.voteaverage < 6{
            rating.trackClr = ColorUtils.desaturatedRGB1X(colorString: "E1E61A")
            rating.progressClr = ColorUtils.hexStringToUIColor(hex: "E1E61A")
            
        } else if movie.voteaverage >= 6{
            rating.trackClr = ColorUtils.desaturatedRGB1X(colorString: "1FD07A")
            rating.progressClr = ColorUtils.hexStringToUIColor(hex: "1FD07A")
            
        }
        rating.setProgressWithAnimation(duration: 1.0, value: movie.voteaverage/10)
        ratingValue.text = String(Int(movie.voteaverage * 10))+"%"
        if let imageURL = movie.poster {
            poster.kf.setImage(with: imageURL)
        }
    }
}
