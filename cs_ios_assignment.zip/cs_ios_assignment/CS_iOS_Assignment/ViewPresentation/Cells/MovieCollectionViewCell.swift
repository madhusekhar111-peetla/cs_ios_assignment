//
//  MovieCollectionViewCell.swift
//  CS_iOS_Assignment
//
//  Created by Madhu S on 21/01/20.
//  Copyright © 2020 Backbase. All rights reserved.
//

import UIKit

class MovieCollectionViewCell: UICollectionViewCell {
    @IBOutlet weak var poster: UIImageView!
    static let identifier: String = "MovieCollectionViewCell"
    @IBOutlet weak var myLabel: UILabel!

    static var nib: UINib {
        return UINib(nibName: identifier, bundle: Bundle(for: self))
    }
    
    override func awakeFromNib() {
        super.awakeFromNib()
    }
    
    func configure(with movie: Movies) {
        if let imageURL = movie.poster {
            poster.kf.setImage(with: imageURL)
        }
    }
}
