//
//  CSMoviesPaginator.swift
//  CS_iOS_Assignment
//
//  Created by Madhu S on 20/01/20.
//  Copyright © 2020 Backbase. All rights reserved.
//

import Foundation
enum CSPaginatedMoviesState {
    case loading
    case palying
    case movies([Movies])
    case playingmovies([Movies])
    case fatalError(String)
    case pageError(String)
}

class CSMoviesPaginator {
    
    var state = Observable(CSPaginatedMoviesState.movies([]))
    
    var lastPage: Int {
        return lock.sync { return self._lastPage }
    }
    
    private var movies: [Int: [Movies]] = [:] {
        didSet {
            state.value = .movies(flattened(movies))
        }
    }
    private var playingmovies: [Int: [Movies]] = [:] {
           didSet {
               state.value = .playingmovies(flattened(playingmovies))
           }
       }
    
    private let lock = DispatchQueue(label: "com.PaginatedMoviesListModel.dispatchQueue")
    private var _lastPage: Int = 0
    
    // Adds movies list into the page and calls the callback with flattened movies list
    func add(movies moviesToAdd: [Movies], toPage page: Int) {
        lock.async { [weak self] in
            guard let self = self else { return }
            var newMovies = self.movies
            newMovies[page] = moviesToAdd
            self._lastPage = max(self._lastPage, page)
            self.movies = newMovies
        }
    }
    func addPlaying(movies moviesToAdd: [Movies], toPage page: Int) {
        lock.async { [weak self] in
            guard let self = self else { return }
            var newMovies = self.playingmovies
            newMovies[page] = moviesToAdd
            self._lastPage = max(self._lastPage, page)
            self.playingmovies = newMovies
        }
        
    }
    
    func clear() {
        lock.async { [weak self] in
            guard let self = self else { return }
            self.movies = [:]
            self.playingmovies = [:]
            self._lastPage = 0
        }
        
    }
    
    func handleAPIError(_ error: CSMovieAPI.APIError) {
        switch error {
        case .parsingError(_), .curruptedData, .emptyResult:
            // if anything has went wrong user can't do anything with it
            state.value = .pageError("There are no more pages")
        case .networkError(let error):
            //that we have some global error so we should allert
            state.value = .fatalError(error.localizedDescription)
        case .badQuery(let query):
            let searchFor = query.isEmpty ? "the empty query" : "\"\(query)\""
            state.value = .fatalError("You can't search for \(searchFor) ")
        }
    }
    
    private func flattened(_ movies: [Int: [Movies]]) -> [Movies] {
        var result = [Movies]()
        for index in movies.keys.sorted() {
            guard let pageMovies = movies[index] else { continue }
            result += pageMovies
        }
        return result
    }

}


