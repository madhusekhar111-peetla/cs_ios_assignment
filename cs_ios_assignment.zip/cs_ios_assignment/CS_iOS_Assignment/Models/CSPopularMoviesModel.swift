//
//  CSPopularMoviesModel.swift
//  CS_iOS_Assignment
//
//  Created by Madhu S on 20/01/20.
//  Copyright © 2020 Backbase. All rights reserved.
//

import Foundation
//protocol CSPopularMoviesModelDelegate {
//    func genresData(data: [Genres])
//}

final class CSPopularMoviesModel {
//    var delegate: CSPopularMoviesModelDelegate?

    private let moviesListPaginator = CSMoviesPaginator()
    private let api: CSMovieAPI
    
    init(api: CSMovieAPI) {
        self.api = api
    }
    
}

extension CSPopularMoviesModel: CSPaginatedMoviesModel {

    var lastPage: Int {
        return moviesListPaginator.lastPage
    }
    
    var state: Observable<CSPaginatedMoviesState> {
        return moviesListPaginator.state
    }
    
    func load(page: Int)  {
        api.discover(page: page, success: {[moviesListPaginator] response in
            moviesListPaginator.add(
                movies: response.results.map(CSMovieAPI.toMovie),
                toPage: page
            )
            
            }, failure: { [moviesListPaginator] error in
                moviesListPaginator.handleAPIError(error)
        })
    }
    
    func playingload(page: Int)  {
        api.playing(page: page, success: {[moviesListPaginator] response in
            moviesListPaginator.addPlaying(
                movies: response.results.map(CSMovieAPI.toMovie),
                toPage: page
            )
            
            }, failure: { [moviesListPaginator] error in
                moviesListPaginator.handleAPIError(error)
        })
    }
    
    
    func movieDetails(movieId: Int,success: @escaping ([Genres]) -> Void)  {
        api.getDetailedMovie(movieId: movieId, success: { response in
            var genres = [Genres]()
            for item in response.genres{
                let genre = Genres(id: item.id, name: item.title)
                genres.append(genre)
            }
            success(genres)
            
        }, failure: { [moviesListPaginator] error in
            moviesListPaginator.handleAPIError(error)
        })
    }
}

