//
//  CSPaginatedMoviesModel.swift
//  CS_iOS_Assignment
//
//  Created by Madhu S on 20/01/20.
//  Copyright © 2020 Backbase. All rights reserved.
//

import Foundation
protocol CSPaginatedMoviesModel {
    func load(page: Int)
    func playingload(page: Int)
    func movieDetails(movieId: Int,success: @escaping ([Genres]) -> Void)
    var state: Observable<CSPaginatedMoviesState> { get }
    var lastPage: Int {get}
}
