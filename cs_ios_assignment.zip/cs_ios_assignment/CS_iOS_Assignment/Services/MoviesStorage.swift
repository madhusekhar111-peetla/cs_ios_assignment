//
//  MoviesStorage.swift
//  CS_iOS_Assignment
//
//  Created by Madhu S on 20/01/20.
//  Copyright © 2020 Backbase. All rights reserved.
//

import Foundation

protocol MoviesSavedInterface {
    init(name: String)
    func save(_ data: [String])
    func load(thenDispatchOn queue: DispatchQueue, onComplete: @escaping ([String])->Void)
}

final class MoviesStorage {
    
    private let filename: String
    
    required init(name: String) {
        self.filename = name
    }
}

extension MoviesStorage: MoviesSavedInterface {
    
    private var fileURL: URL? {
        let dir = FileManager.SearchPathDirectory.cachesDirectory
        guard let url = FileManager.default.urls(for: dir, in: .userDomainMask).first else { return  nil }
        return url.appendingPathComponent(filename)
    }
    
    func save(_ data: [String]) {
        let encoder = JSONEncoder()
        guard let fileURL = fileURL else { return }
        DispatchQueue.global(qos: .background).async {
            guard let fileData = try? encoder.encode(data) else { return }
            FileManager.default.createFile(atPath: fileURL.path, contents: fileData, attributes: nil)
        }
    }
    
    func load(thenDispatchOn queue: DispatchQueue, onComplete: @escaping ([String])->Void) {
        guard let fileURL = fileURL else { return }
        DispatchQueue.global(qos: .background).async {
            guard let data = FileManager.default.contents(atPath: fileURL.path)
                , let list = try? JSONDecoder().decode([String].self, from: data)
                else { return }
            queue.async {
                onComplete(list)
            }
        }
    }
    
}
