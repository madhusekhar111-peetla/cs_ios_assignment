//
//  CSMovieService.swift
//  CS_iOS_Assignment
//
//  Created by Madhu S on 20/01/20.
//  Copyright © 2020 Backbase. All rights reserved.
//

import Foundation

    
   final class CSMovieService {
        
        private let storageName = "Movie-suggestions"
        private(set) var suggestions = Observable([String]())
        
        private let storage: MoviesSavedInterface
        
        
        init(capacity: Int, storage: MoviesSavedInterface) {
            self.suggestions.value = Array(repeating: "", count: capacity)
            self.storage = storage
            self.loadSuggestions()
        }
        
        func add(search query: String) {
            guard !suggestions.value.contains(query) else { return }
            var new = [query] + suggestions.value.reversed()
            if new.count > suggestions.value.count { _ = new.popLast() }
            new.reverse()
            suggestions.value = new
            storage.save(new)
        }
        
        private func loadSuggestions() {
            storage.load(thenDispatchOn: .main) { [weak self] list in
                guard let self = self else { return }
                let capacity = self.suggestions.value.count
                self.suggestions.value = Array(list.suffix(capacity))
            }
        }
        

    }
