//
//  CSMoviesResponse.swift
//  CS_iOS_Assignment
//
//  Created by Madhu S on 20/01/20.
//  Copyright © 2020 Backbase. All rights reserved.
//

import Foundation
extension CSMovieAPI {

    struct CSMoviesResponse: Codable {
        let page: Int
        let totalResults: Int
        let totalPages: Int
        let results: [MovieResponse]
        
        enum CodingKeys: String, CodingKey {
            case page = "page"
            case totalResults = "total_results"
            case totalPages = "total_pages"
            case results = "results"
        }
    }
    
    struct CSMoviesDetailsResponse: Codable {
        let genres: [GenresResponse]
        
        enum CodingKeys: String, CodingKey {
            case genres = "genres"

        }
    }
    struct GenresResponse: Codable {
        let id: Int
        let title: String
        
        enum CodingKeys: String, CodingKey {
            case id = "id"
            case title = "name"
        }
    }
    
    struct MovieResponse: Codable {
        let id: Int
        let title: String
        let posterPath: String?
        let overview: String?
        let releaseDate: DateFormat
        let popularity: Float
        let votecount: Int
        let video: Bool
        let adult: Bool
        let originallanguage: String
        let backdrop: URL?
        let voteaverage: Float
        
        
        enum CodingKeys: String, CodingKey {
            case id = "id"
            case title = "title"
            case posterPath = "poster_path"
            case overview = "overview"
            case releaseDate = "release_date"
            case popularity = "popularity"
            case votecount = "vote_count"
            case video = "video"
            case adult = "adult"
            case originallanguage = "original_language"
            case backdrop = "backdrop_path"
            case voteaverage = "vote_average"
            
        }
    }
    
}

extension CSMovieAPI {
    
    struct DateFormat: Codable {
        let date: Date
        
        private static let formatter: DateFormatter = {
            let formatter = DateFormatter()
            formatter.dateFormat = "yyyy-MM-dd"
            return formatter
        }()
        
        init(from decoder: Decoder) throws {
            let container = try decoder.singleValueContainer()
            let rawValue = try container.decode(String.self)
            guard let date = DateFormat.formatter.date(from: rawValue) else {
                throw APIError.parsingError("\(rawValue) doesn't match the format \(DateFormat.formatter.dateFormat ?? "") ")
            }
            self.date = date
        }
        
        func encode(to encoder: Encoder) throws {
            var container = encoder.singleValueContainer()
            try container.encode(DateFormat.formatter.string(from: date))
        }
    }
}
