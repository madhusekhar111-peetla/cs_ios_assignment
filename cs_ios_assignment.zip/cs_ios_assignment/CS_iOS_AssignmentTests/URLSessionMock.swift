//
//  URLSessionMock.swift
//  CS_iOS_AssignmentTests
//
//  Created by Madhu S on 24/01/20.
//  Copyright © 2020 Backbase. All rights reserved.
//

import UIKit
import XCTest
@testable import CS_iOS_Assignment

class URLSessionMock: CSMovieSessionProtocol {
    func dataTask(with request: URLRequest, completion: @escaping (Data?, URLResponse?, Error?) -> Void) -> URLSessionDataTaskProtocol {
        defer {
            completion(completionData, completionResponse, completionError)
        }
        
        return URLSessionDataTaskMock()
    }
    
    var completionData: Data?
    var completionResponse: URLResponse?
    var completionError: Error?
    
}
class URLSessionDataTaskMock: URLSessionDataTaskProtocol {
    
    private (set) var state: URLSessionTask.State = .suspended
    
    func cancel() { state = .canceling }
    func suspend() { state = .suspended }
    func resume() { state = .running }
}
