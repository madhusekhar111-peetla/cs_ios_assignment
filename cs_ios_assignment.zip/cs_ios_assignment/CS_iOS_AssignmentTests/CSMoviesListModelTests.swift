//
//  CSMoviesListModelTests.swift
//  CS_iOS_AssignmentTests
//
//  Created by Madhu S on 22/01/20.
//  Copyright © 2020 Backbase. All rights reserved.
//

import XCTest
@testable import CS_iOS_Assignment

class CSMoviesListModelTests: XCTestCase {

    func testLoadNext_firstTimeValidData_shouldReturn20Movies() {
        let exp = expectation(description: "Valid response")
        let sessionMock = URLSessionMock()
        sessionMock.completionData = JSONMocks.valid
        let apiMock = CSMovieAPI(session: sessionMock)
        let sut = CSPopularMoviesModel(api: apiMock)
        let _ = sut.state.subscribe { state in
            switch state {
            case .movies(let movies):
                if movies.count == 20 { exp.fulfill() }
            default: XCTFail("must be movies result")
            }
        }
        sut.load(page: 1)
        waitForExpectations(timeout: 1, handler: nil)
    }
    
    
    // MARK: Thread safety tests
    
    func testLoadNext_20TimesValidDataFromRandomThread_shouldReturnAllMoviesAndLastpageEquals20() {
        let exp = expectation(description: "Valid response")
        let sessionMock = URLSessionMock()
        sessionMock.completionData = JSONMocks.valid
        let apiMock = CSMovieAPI(session: sessionMock)
        let sut = CSPopularMoviesModel(api: apiMock)
        
        
        let _ = sut.state.subscribe { state in
            switch state {
            case .movies(let movies):
                if movies.count == 20*20, sut.lastPage == 20 { exp.fulfill() }
            default: XCTFail("must be movies result")
            }
        }
       
        DispatchQueue.concurrentPerform(iterations: 20) { iteration in
            sut.load(page: iteration+1)
        }
        
        waitForExpectations(timeout: 3, handler: nil)
    }
    
}
