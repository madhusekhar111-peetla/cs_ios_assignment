//
//  CSInstantiationsTests.swift
//  CS_iOS_AssignmentTests
//
//  Created by Madhu S on 22/01/20.
//  Copyright © 2020 Backbase. All rights reserved.
//

import XCTest
@testable import CS_iOS_Assignment
class CSInstantiationsTests: XCTestCase {

    
    func testMovieDetailsViewControllerInstantiation() {
        let _ = CSMovieDetailsViewController.instantiate()
    }
    
    func testMoviesListViewControllerInstantiation() {
        let _ = CSMoviesListViewController.instantiate()
    }
     


}
